/*
 * ServoSensor.h
 *
 * Created: 22.08.2011 17:17:29
 *  Author: operator
 */ 


#ifndef SERVOSENSOR_H_
#define SERVOSENSOR_H_

extern  void  vSensor ( void * pvParameters);

extern  void  vServo ( void * pvParameters);

#endif /* SERVOSENSOR_H_ */